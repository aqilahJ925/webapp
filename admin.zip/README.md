# webapp
Group: SEG01-02
Members: 
Ellysia Eva Anak Winston
Siti Az'zaharah Binti Zuhry
Nur Ainainihanan Binti Rozman
Siti Aisyah Safiah Binti Hassan
Nuraqilah Binti Jolihi

A web application for EasyStorage - Online Storage Services for universities students.
